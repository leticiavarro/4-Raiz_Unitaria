# Raizes Unitárias
Slides e códigos sobre Raizes Unitárias e Teste DF - Dick Fuller. Aula 4 na disciplina de Econometria Avançada- Séries Temporais na USJT.
